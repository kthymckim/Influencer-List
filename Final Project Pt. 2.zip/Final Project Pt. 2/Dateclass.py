# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 14:54:46 2019

@author: jadec
"""



class Date:
    """ A class that stores and manipulates dates,
        represented by a day, month, and year.
    """

    # Problem 1: The constructor for the Date class.
    def __init__(self, new_month, new_day, new_year):
        """ constructor that initializes the three attributes  
            in every Date object (month, day, and year)
        """
        # add the necessary assignment statements below
        self.month = new_month
        self.day = new_day
        self.year = new_year

    # The function for the Date class that returns a Date
    # object in a string representation.
    def __repr__(self):
        """ This method returns a string representation for the
            object of type Date that it is called on (named self).

            ** Note that this _can_ be called explicitly, but
              it more often is used implicitly via printing or evaluating.
        """
        s = '%02d/%02d/%04d' % (self.month, self.day, self.year)
        return s

    def is_leap_year(self):
        """ Returns True if the called object is
            in a leap year. Otherwise, returns False.
        """
        #if the year divides by 400 it is a leap year
        if self.year % 400 == 0:
            return True
        #if it divides by 100 it is not a leap year
        elif self.year % 100 == 0:
            return False
        #if the year divides bt 4 it is a leap year
        elif self.year % 4 == 0:
            return True
        #anything else is false
        return False

    def copy(self):
        """ Returns a new object with the same month, day, year
            as the called object (self).
        """
        new_date = Date(self.month, self.day, self.year)
        return new_date


    # problem 3
    def tomorrow(self):
        """Returns a new object that is after the inputed object (self)
        """
        #list of days in each month
        days_in_month = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        #if the object's month is December and the day is the last day of 
        #december, advance the month and the day to circle around  and year to add 1
        if self.month == 12 and self.day == days_in_month[self.month]:
            self.day = 1
            self.month = 1
            self.year += 1
        #if it is the last day of the month, reset day, go to next month
        elif self.day == days_in_month[self.month]:
            #if its a leap year and the month is february, there is 1 more day 
            #in the month 
            if self.is_leap_year() and self.month == 2:
                self.day += 1
            else:
                self.day = 1
                self.month += 1
                #if the day is greater than or equal to the amount of days in 
                #that month, go to the next month and the day is 1
        elif self.day >= days_in_month[self.month]:
            self.month += 1
            self.day = 1
        #any other day of the year, add 1 day
        else:
            self.day += 1
            
    def yesterday(self):
        """ returns a new object that is before the inputed object (self)
        """
        days_in_month = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        #if the object's month is December and the day is the last day of 
        #december, advance the month and the day to circle around  and year to add 1
        if self.month == 1 and self.day == 1:
            self.day = days_in_month[12]
            self.month = 12
            self.year -= 1
                #if it is the last day of the month, reset day, go to next month
        elif self.day == 1:
            #if its a leap year and the month is february, there is 1 more day 
            #in the month 
            if self.is_leap_year() and self.month == 3:
                self.day = 29
                self.month -= 1
            else:
                self.day = days_in_month[self.month - 1]
                self.month -= 1

            #any other day of the year, subtract 1 day
        else:
            self.day -= 1
        
    # pseudonym
    advance_one = tomorrow
    
    # problem 4
    def add_n_days(self, n):
        """Returns a new object that is n days forward from the input object 
        (self)
        """
        #loop tomorrow n amount of times and print all of the days in between
        for i in range(n):
            print(self)
            self.tomorrow()
        print(self)
        
    def subt_n_days(self, n):
        """Retunrs a new obkect that is n days backwards from the input object
        (self) """
        #loop yesterday n amount of times and print the last time
        for i in range(n):
            self.yesterday()
        print(self)

    # problem 5
    def __eq__(self, other):
        """Returns true if the input object other and input object self are
        the same date
        """
        #if the month, day, and year of each object are the same return true
        if self.day == other.day and self.month == other.month and self.year == other.year:
            return True
        else:
            #if something isnt the same, return false
            return False
                

    # problem 6
    def is_before(self, other):
        """Returns true if the input object other is before the object self
        """
        #if self annd other are the ame date then self is not before other
        if self == other:
            return False 
        #if self's year is before other's year, return false
        elif self.year > other.year:
            return False
        elif self.year == other.year: 
            #if the years are the same but selfs month is greater than others 
            #month return false
            if self.month > other.month:
                return False
            #if the years are the same and self's month is the same but the 
            #day is greater than  other's day, return return false
            elif self.month == other.month and self.day > other.day:
                return False
            #years are the same, month is the same but day is less than return true
            else:
                return True
        #anything else return true
        else:
            return True
            
        

    # problem 7
    def is_after(self, other):
        """Returns true if the object self is after the object other
        """
        #if self and other are the same date return false
        if self == other:
            return False
        #if self is before other return false
        elif self.is_before(other) == True:
            return False
        #else retrun true
        else:
            return True

    # problem 8
    def diff(self, other):
        """Returns how many days the object self is away from the object other
        """
        #make a copy of self and other
        selfie = self.copy()
        otherie = other.copy()
        #initialize count
        count = 0
        #if they are the same date, return count
        if selfie == otherie:
            return count
        #while the dates are different, 
        while selfie != otherie:
            #is the object self is before the object other, get the date of 
            #tomorrow and minus 1 t the count
            if selfie.is_before(otherie) == True:
                selfie.tomorrow()
                count -= 1
            #if self is after other continue to get the tomorrow for other and
            #add1 to the count
            else:
                otherie.tomorrow()
                count += 1
            #return the count
        return count
            
            
    days_between = diff       

    # problem 9
    def day_of_week(self):
        """Return the day of the week that the object self falls on 
        """
        #initialize a date
        other = Date(4, 2, 2018)
        #here are all the days of the week in order
        day_of_week_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday',
                     'Friday', 'Saturday', 'Sunday']
        #see how many days there are between self and the initialized date
        differ = self.diff(other) % 7 #finds index of which day 
        return day_of_week_names[differ]
    #pseudonym    
    day_name = day_of_week
