# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 14:47:23 2019

@author: jadec
"""

import tweepy
import csv
import pandas as pd
import sys
import time
import datetime
from Dateclass import Date
from Twitterdataclass import Twitterdata
import random

# list of usernames (text file)
# check if followers are over a certain number
# then find their followers and following
# then find those in both followers and following
#
company = input('What is the name of your company?')
hashtag = '#' + input('What is the name of your product you would like to promote?')
threshold = input('The people I want to promote my product should have more than ___ followers on Twitter.')
names = input('How many names would you like to recieve?')

class Influencers:
    """ Reads a text file of people who tweeted the specified product and
    determines which have over a specified number of followers. Finds each of
    their mutual followers (those being followed and following them) make a
    dictionary of those usernames and then index using random import to return
    the specified number of names.
    """
    def __init__(self, threshold, names):
        """ Initiates variables """
        self.Twitterdata = Twitterdata(company, hashtag)
        self.threshold = threshold
        self.number_of_names = names
        self.usernames = self.Twitterdata.findUserFromHashtag()

    def __repre__(self):
        """represents the list of names that could promote the product in a string"""
        final = self.final()
        for name in final:
            print (final[name].title())

        
# make list then get rid of repeat usernames    
    def Txt_to_list(self):
        """ Converts the text file of usernames to a list and removes repeats. 
        """
       
        f = open(self.usernames, 'r')
        x = [line.rstrip('\n').split() for line in f]
        res = [i for n, i in enumerate(x) if i not in x[:n]] 
        return res

    def Over_threshold(self):
        """ Remove people from the list who have less followers than specified
        by the threshold.
        """
        a = self.Txt_to_list
        for i in range(len(a)):
            if len(a) < self.threshold:
                a = [x for x in a if x != a[i]]   
                return a
            else:
                return a
        
    def Final(self):
        """ Creates a final List of accounts"""
        m = self.Over_threshold()
        n = random.randint(1, len(m))
        final = []
        for i in range(self.number_of_n):
            final += m[n]        
        for name in final:
            print (final[name].title())
            
        
    
__name__ = "__main__" 
I = Influencers(threshold, names)       
print(I.Final)