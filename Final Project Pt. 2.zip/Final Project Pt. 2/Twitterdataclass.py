# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 14:56:34 2019

@author: jadec
"""
import tweepy
import csv
import pandas as pd
import sys
import time
#info on the class datetime from https://learnandlearn.com/python-programming/python-reference/python-get-current-date (12/12/19)
import datetime
from Dateclass import Date

#info on tweepy and how to get started from https://tweepy.readthedocs.io/en/latest/code_snippet.html


# code from https://www.digitalocean.com/community/tutorials/how-to-authenticate-a-python-application-with-twitter-using-tweepy-on-ubuntu-14-04
CONSUMER_KEY = 'HjjyZiXXUkDKCt7a1vLM0uaBu'
CONSUMER_SECRET = 'ky3sDwxWzEXQO7QTphqsAqthxU2rQVVvL45P8h6ofCig6jYVDB'
ACCESS_TOKEN = '1203048090581848065-qb5RLoMQt4cciTMivsT1B8kJUqMme4'
ACCESS_TOKEN_SECRET = 'qB8xB1iSRTHD2AVvXI4V1xfxK7ZqV0crxcTyVAjOXm88Q'

auth = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
auth.set_access_token(ACCESS_TOKEN, ACCESS_TOKEN_SECRET)


#status = "Testing!"
#api.update_status(status=status)
#this works, now what else can i do

#code from https://gist.github.com/sxshateri/540aead254bfa7810ee8bbb2d298363e
#by sxshateri
#this should create a new file and in the file write all of the tweets with a specific hashtag 
api = tweepy.API(auth,wait_on_rate_limit=True,wait_on_rate_limit_notify=True)

company = input('What is the name of your company?')
hashtag = '#' + input('What is the name of your product you would like to promote?')
threshold = input('The people I want to promote my product should have more than ___ followers on Twitter.')
names = input('How many names would you like to recieve?')

class Twitterdata:
    """ Class that stores all of the inputs and manipulates them to create 
    source material for the other classes"""
    def __init__(self, company, hashtag):
        """initializes all of the comany's input attributes"""
        #naming the components of the class Twitterdata
        self.company = company
        self.hashtag = hashtag

        
    def __repr__(self):
        """returns a string representation of the attributes"""
        print('The company, ' + str(self.company) + ', would like ' + str(self.names)\
              + ' names of people with over ' + str(self.threshold) +\
              ' followers who might like to promote ' + str(self.hashtag) + '.')
        

        
#function adapted from https://gist.github.com/sxshateri/540aead254bfa7810ee8bbb2d298363e
#retrieved 12/8/19
#by sxshateri        
    def findUserFromHashtag(self):
        """finds a list of tweets with the specified hashtag and creates a text
        file of all of the usernames of people who have tweeted with that hashtag"""
    # Open/Create a file to append data
        HashtagFile = open(self.hashtag +'.txt', 'w')
# search start date value. the search will start from this date to the current date.
        today = datetime.datetime.today()
        StartDate = self.dayToStart(today)
# getting the search word/hashtag from user and storing the usernames of the people who tweeted that hashtag in a file
        for tweet in tweepy.Cursor(api.search,q=self.hashtag,count=20,lang="en",since=StartDate, tweet_mode='extended').items(100):

            HashtagFile.write(str(tweet.user.screen_name + ' '))

        print ("Scraping finished and saved to "+ self.hashtag +".txt")
        #close file
        HashtagFile.close()
        return HashtagFile
    
    def dayToStart(self, today):
        """ find the day 365 days before the current date"""
        #set each part of the Date class
        month = today.month
        day = today.day
        year = today.year
        d = Date(month, day, year)
        #find date any amount of days before today
        startdate = d.subt_n_days(365)
        return startdate
 
    #the following 2 functions adapted from: https://stackoverflow.com/questions/52450621/get-list-of-followers-and-following-for-group-of-users-tweepy/52452208
    #by jschnurr
    #12/8/19
#how to get a list of followers for a specific account
    def list_following(self, username):
        """ gets a list of usernames of all of usernames the account is following for a specific account
        input: a username in the form a string """
        #create file to store all of the screen names of the people following the input string username
        FollowingFile = open('Following' + username + '.txt', 'w')
        #getting all of the screen names of the people following the username and writing the names into the file
        for user in tweepy.Cursor(api.friends, screen_name=username).items(100):
            FollowingFile.write(str(user.screen_name) + ' ')
        time.sleep(5.05)
        print('Scraping finished and saving to Following ' + username + '.txt')

                
        #close the txt file
        FollowingFile.close()
        return FollowingFile
    
#how to get a list of followers for a specific account
    def list_followers(self, username):
        """ gets a list of usernames of all of the followers for an account
        input: a username in the form a string """
        #creates a file to put the screen names
        FollowerFile = open('Followes' + username + '.txt', 'w')
        #get the screen names of all the people following the input username and put them into the file
        for user in tweepy.Cursor(api.followers, screen_name=username).items(100):
            FollowerFile.write(str(user.screen_name) + ' ')
        time.sleep(5.05)
        print('Scraping finished and saved to Follows' + username + '.txt')
        #close the file
        FollowerFile.close()
        return FollowerFile
    
__name__ == "__main__"
T = Twitterdata(company, hashtag)


